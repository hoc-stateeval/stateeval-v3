
import {
  Typography,
} from '@mui/material';

const Dashboard = () => {
  return (
    <>
      <Typography variant="h2">Summative Eval Dashboard</Typography>
    </>
  );
};

export default Dashboard;