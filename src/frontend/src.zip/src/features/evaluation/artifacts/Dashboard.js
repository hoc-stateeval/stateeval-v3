import {
  Typography,
} from '@mui/material';

const Dashboard = () => {
  return (
    <>
    <Typography variant="h2">Artifacts</Typography>
    </>
  );
};

export default Dashboard;