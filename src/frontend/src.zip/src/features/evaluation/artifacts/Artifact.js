import {
  Typography,
} from '@mui/material';

const Artifact = () => {
  return (
    <>
    <Typography variant="h4">Artifact</Typography>
    </>
  );
};

export default Artifact;