const Artifacts = () => {
  return (
    <>
    </>
  )
}

export default Artifacts;