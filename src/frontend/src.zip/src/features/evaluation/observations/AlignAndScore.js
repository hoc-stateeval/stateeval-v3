const AlignAndScore = () => {
  return (
    <>
    </>
  )
}

export default AlignAndScore;