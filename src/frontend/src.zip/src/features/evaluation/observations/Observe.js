const Observe = () => {
  return (
    <>
    </>
  )
}

export default Observe;