
import {
  Typography,
} from '@mui/material';

const Dashboard = () => {
  return (
    <>
      <Typography variant="h2">Mid-year Eval Dashboard</Typography>
    </>
  );
};

export default Dashboard;