import {
  Typography,
} from '@mui/material';

const Dashboard = () => {
  return (
    <>
      <Typography variant="h2">SGG Dashboard</Typography>
    </>
  );
};

export default Dashboard;