
import {
  Typography,
} from '@mui/material';

const Dashboard = () => {
  return (
    <>
      <Typography variant="h2">Self Assessments Dashboard</Typography>
    </>
  );
};

export default Dashboard;